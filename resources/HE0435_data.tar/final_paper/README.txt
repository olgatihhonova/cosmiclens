================================================================================
H0LiCOW II. Spectroscopic survey and galaxy-group identification of
the strong gravitational lens system

D. Sluse, A. Sonnenfeld, N. Rumbaugh, C. E. Rusu, C. D. Fassnacht,
T. Treu, S. H. Suyu, K. C. Wong, M. W. Auger, V. Bonvin, T. Collett,
F. Courbin, S. Hilbert, L. V. E. Koopmans, P. J. Marshall, G. Meylan,
C. Spiniello, M. Tewes.

      <Monthly Notices of the Royal Astronomical Society ???, ??? (2017)>
      =2017MNRAS...???..???S

      arXiv: https://arxiv.org/abs/1607.00382
================================================================================
Keywords: Gravitational lensing: strong -- quasars: individual:
HE0435-1223 -- galaxies: groups: general

Abstract: We provide a catalog of spectroscopically targeted objects
     located in the field of view of the gravitationally lensed system
     HE0435-1223, as well as the associated 1-D extracted spectra. Our
     catalog gathers spectra obtained with the VLT-FORS spectrograph
     and the GRIS300V grism\,+\,GG435 blocking filter (i.e. covering a
     large fraction of the range 4000-9000\AA; (PID: 091.A-0642(A),
     PI: D.\,Sluse), with the GMOS spectrograph at Gemini-South using
     the R400 grating with GG455 filter (i.e. covering a good fraction
     of the range 4400-10000 \AA; PID: GS0213B-Q-28, PI: T. Treu), and
     with the Keck Low Resolution Imaging Spectrometer LRIS
     (dispersing the light into a blue and a red arms yielding a total
     wavelength coverage from 3600 to 8200 \AA; PI: Fassnacht). The
     catalog is complemented by another spectroscopic catalog of the
     galaxies located in the field-of-view of HE0435-1223 established
     by Momcheva et al. 2015 (2015ApJS..219...29M). One-dimensional
     extracted spectra are provided only for the FORS, GMOS and
     Keck-based observations.

Description: The catalog (cat0435_v1c.fits) is in ``fits-table'' format
	and contains 6 columns.  Columns \#1 to \#6 are objects name,
	ID, position (RA-DEC), redshift z and its uncertainty sigma_z,
	quality flag (ZQF) and tentative object classification. The
	object name is defined as follows: Instrument\_date\_objID,
	where instrument is FORS, Gemini or Keck if the redshift is
	derived from our survey, and Momcheva if the redshift comes
	from Momcheva et al. 2015 (2015ApJS..219...29M). The ``date''
	in format yyyymmdd is the date of observation, or 201508 for
	objects from Momcheva et al. (2015). Note that duplicated
	objects have been removed from the catalog. The quality flag
	definition is as follows: zQF=0/1/2 if the redshift is
	extracted from this program and 3,4,5,6 refer to objects from
	MOM15. zQF=0 for secure redshift; zQF=1 for tentative
	redshift; zQF=2 for unreliable/unknown redshift; zQF=3 for
	data obtained with LDSS-3; zQF=4 for data obtained with IMACS;
	zQF=5 for data obtained with Hectospec; zQF=6 for NED
	objects. The object type is not based on an accurate
	characterization of the object properties but is based on
	clear observational signatures. The classification proceeds as
	follows: Type=ETG-Sx if CaK-H and/or G-band are detected;
	Type=Starburst if clear emission lines are observed,
	Type=M-dwarf for a M-dwarf star; Type=Star for other
	stellar-types; Type=Unknown if no identification could be done
	or if the spectrum is from an external catalog. For all the
	objects but those from Momcheva et al. (2015), we also provide
	a 1D extracted spectrum in fits format. The filename
	corresponds for the object name in the catalog except for the
	spectra obtained at Keck where 2 spectra obtained with the
	blue and red arms are provided (except for obj. 1102 and
	1103). For those spectra, we appended "_blue"/"_red" to the
	object name to identify the wavelength range covered by the
	spectra.
